# श्री राम आपले सरकार सेवा केंद्र — Application System

- ऑनलाइन अर्ज फॉर्म
- सेवा विभाग व सेवेचे नाव
- अर्जदाराची माहिती
- कागदपत्र निवड / file preview list
- Application ID निर्माण
- Application Status lookup
- Admin Login / Dashboard
- Admin status update व note
- अर्ज submit झाल्यावर WhatsApp वर अर्जाची माहिती पाठवण्याची सुविधा
- Application ID copy सुविधा
- दिलेला श्री राम लोगो वापरलेला आहे

टीप: सध्याची आवृत्ती browser-local application storage वापरते. ग्राहकाच्या वेगळ्या device वरून आलेले अर्ज कायमस्वरूपी central database मध्ये दाखवण्यासाठी पुढील टप्प्यात Vercel Storage/Database credentials जोडणे आवश्यक आहे. WhatsApp submission हा सध्याचा practical remote fallback आहे.
