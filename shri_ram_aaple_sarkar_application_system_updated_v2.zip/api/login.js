export default function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({ok:false});
  let body=req.body||{};
  const id=String(body.id||'');
  const password=String(body.password||'');
  // Default credentials. Change these in the server-side function before sharing with others.
  const valid=id==='admin' && password==='ShriRam@2026';
  if(!valid) return res.status(401).json({ok:false});
  res.setHeader('Set-Cookie','admin_session=loggedin; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=28800');
  return res.status(200).json({ok:true});
}