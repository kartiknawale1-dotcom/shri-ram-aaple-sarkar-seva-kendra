export default function handler(req,res){
  const cookie=String(req.headers.cookie||'');
  const ok=cookie.split(';').some(x=>x.trim()==='admin_session=loggedin');
  return res.status(200).json({ok});
}